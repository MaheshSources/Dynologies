export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCXCStz_btUkXp95BSxVFF-WEBZJfb02LI",
    authDomain: "dynologies-demo.firebaseapp.com",
    databaseURL: "https://dynologies-demo.firebaseio.com",
    projectId: "dynologies-demo",
    storageBucket: "",
    messagingSenderId: "726289153801",
    appId: "1:726289153801:web:0efefb2335912251"
  }
};
