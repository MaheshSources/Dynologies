export class LoginRequestModel {
    Client_Id: string;
    Grant_Type: string;
    UserName: string;
    Password: string;
}